const sessionidtousermap = new Map();

function setUser(id, user) {
    sessionidtousermap.set(id, user); // Store the user with the session ID as the key
}

function getUser(id) {
    return sessionidtousermap.get(id); // Retrieve the user by session ID
}

module.exports = {
    setUser,
    getUser,
};
