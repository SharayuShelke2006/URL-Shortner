const shortid = require("shortid");
const URL = require("../models/url");
const path = require("path");
const express = require("express");
const app = express();
//views
app.set("view engine","ejs");
app.set("views",path.resolve("./views"));

async function handleGenerateNewShortURL(req,res) {
    const body = req.body;
    const shortID = shortid.generate();
    if(!body.url)
        { 
            return res.status(400).json({error:'url is required'})
        }
    await URL.create(
        {shortId : shortID,
        redirectURL: body.url,
        visitHistory :[],
    }

    );
    return res.render("home",{
        short_id : shortID,
    });
}
module.exports={
    handleGenerateNewShortURL,
}