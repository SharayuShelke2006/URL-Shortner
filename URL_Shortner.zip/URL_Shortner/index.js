const express = require("express");
const app = express();
const PORT = 8001;
const path = require("path");
const cookieparser = require("cookie-parser");
const {restricttologgedinuseronly} = require("./middleware/auth");
//views
app.set("view engine","ejs");
app.set("views",path.resolve("./views"));

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieparser());

// Routes and Models
const userRoute = require("./routes/user");
const urlRoute = require("./routes/url");
const URL = require("./models/url");
const { connectToMongoDB } = require("./connection");

// Use URL route
app.use("/url", restricttologgedinuseronly,urlRoute);
app.use("/user",userRoute);

app.get("/index",restricttologgedinuseronly,async (req,res)=>{
    res.render("index");
});

//signup
app.get("/signup",(req,res)=>{
    res.render("signup")
});

//login
app.get("/login",async (req,res)=>{
    res.render("login");
})
// Short URL redirection route
app.get("/:shortId", async (req, res) => {
    const shortId = req.params.shortId;

    try {
        // Find and update the entry
        const entry = await URL.findOneAndUpdate(
            { shortId }, // Query by shortId
            {
                $push: {
                    visitHistory: { timestamp: Date.now() },
                },
            },
            { new: true } // Return the updated document
        );

        if (!entry) {
            console.error(`No entry found for shortId: ${shortId}`);
            return res.status(404).json({ error: "Short URL not found" });
        }

        // Redirect to the original URL
        res.redirect(entry.redirectURL);
    } catch (error) {
        console.error("Error in /:shortId route:", error);
        res.status(500).json({ error: "Internal Server Error" });
    }
});

// MongoDB Connection
connectToMongoDB("mongodb://127.0.0.1:27017/shortURL")
    .then(() => console.log("MongoDB connected"))
    .catch((error) => {
        console.error("MongoDB connection error:", error);
        process.exit(1);
    });


// Start server
app.listen(PORT, () => console.log("Server started at " + PORT));
