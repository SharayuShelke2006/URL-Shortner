const express = require("express");
const router = express.Router();
const {handelusersignup} = require("../controllers/users");
const {handeluserslogin} = require("../controllers/users");

router.post("/",handelusersignup);
router.post("/login",handeluserslogin)
module.exports=router;