const mongo = require("mongoose");

async function connectToMongoDB(url){
    return mongo.connect(url);
}

module.exports = {
    connectToMongoDB,
}